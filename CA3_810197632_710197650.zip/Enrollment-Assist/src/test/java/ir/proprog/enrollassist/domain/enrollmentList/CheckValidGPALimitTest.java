package ir.proprog.enrollassist.domain.enrollmentList;

import ir.proprog.enrollassist.domain.EnrollmentRules.EnrollmentRuleViolation;
import ir.proprog.enrollassist.domain.course.Course;
import ir.proprog.enrollassist.domain.major.Major;
import ir.proprog.enrollassist.domain.program.Program;
import ir.proprog.enrollassist.domain.section.ExamTime;
import ir.proprog.enrollassist.domain.section.PresentationSchedule;
import ir.proprog.enrollassist.domain.section.Section;
import ir.proprog.enrollassist.domain.student.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(Parameterized.class)
public class CheckValidGPALimitTest {
    public static Section OperatingSystem;
    public static Section ArtificialInteligence;
    public static Student student1;
    public static Student student2;
    public static Student  student3;
    public static Student student4;
    public EnrollmentList enrollmentList;
    public int expectedViolations;
    public String violationMessage;

    public CheckValidGPALimitTest (EnrollmentList enrollmentList, int expectedViolations, String violationMessage) {
        this.enrollmentList = enrollmentList;
        this.expectedViolations = expectedViolations;
        this.violationMessage = violationMessage;
    }
    public static void setUp() throws Exception {
        Major m = new Major("10", "CS", "Engineering");
        Program program = new Program(m, "Undergraduate", 1, 20, "Major");
        Course artificial_inteligence = new Course("1234567", "AI", 4, "Undergraduate");
        Course operatingSystem = new Course("2345678", "OS", 4, "Undergraduate");
        program.addCourse(artificial_inteligence, operatingSystem);
        OperatingSystem = new Section(operatingSystem, "4", new ExamTime("2021-08-01T08:00", "2021-08-01T09:30"), Collections.singleton(new PresentationSchedule("Saturday", "09:00", "10:30")));
        ArtificialInteligence = new Section(artificial_inteligence, "5", new ExamTime("2021-09-01T08:00", "2021-09-01T09:30"), Collections.singleton(new PresentationSchedule("Saturday", "09:00", "10:30")));
        Student student1 = new Student("810197632", "Undergraduate");
        student1.addProgram(program);
        student1.setGrade("00001", operatingSystem, 6);
        Student student2 = new Student("810197650", "Undergraduate");
        student2.addProgram(program);
        student2.setGrade("00001", operatingSystem, 9);
        student2.setGrade("00001", artificial_inteligence, 7);
        Student student3 = new Student("810197645", "Undergraduate");
        student3.addProgram(program);
        student3.setGrade("00001", artificial_inteligence, 19);
        student3.setGrade("00001", operatingSystem, 15);
        Student student4 = new Student("810197676", "Undergraduate");
        student4.addProgram(program);

    }

    static {
        try{
            setUp();
        }catch (Exception e){}
    }
    @Parameters
    public static Collection<Object[]> parameters() throws Exception {
        EnrollmentList not_met_min_valid_gpa_limit = new EnrollmentList("not_met_min_valid_gpa_limit", student1);
        not_met_min_valid_gpa_limit.addSection(OperatingSystem);

        EnrollmentList max_14_exceed_gpa_limit = new EnrollmentList("max_14_exceed_gpa_limit", student2);
        max_14_exceed_gpa_limit.addSection(ArtificialInteligence);

        EnrollmentList max_20_exceed_gpa_limit = new EnrollmentList("max_20_exceed_gpa_limit", student3);
        max_20_exceed_gpa_limit.addSection(ArtificialInteligence);
        max_20_exceed_gpa_limit.addSection(OperatingSystem);


        EnrollmentList first_max_20_exceed_gpa_limit = new EnrollmentList("max_20_exceed_gpa_limit", student4);
        first_max_20_exceed_gpa_limit.addSection(ArtificialInteligence);
        first_max_20_exceed_gpa_limit.addSection(OperatingSystem);

        return Arrays.asList(new Object[][]{
                {not_met_min_valid_gpa_limit, 1, "Minimum number of credits(12) is not met."},
                {max_14_exceed_gpa_limit, 1, "Maximum number of credits(14) exceeded."},
                {max_20_exceed_gpa_limit, 1, "Maximum number of credits(20) exceeded."},
                {first_max_20_exceed_gpa_limit, 1, "Maximum number of credits(20) exceeded."},
        });


    }


    @Test
    public void CheckValidGPALimitTest() {
        List<EnrollmentRuleViolation> violations = enrollmentList.checkValidGPALimit();
        System.out.print(violations.get(0).toString());
        assertEquals(this.violationMessage, violations.get(0).toString());
    }
}
