package ir.proprog.enrollassist.domain.program;

public enum ProgramType {
    Major, Minor
}
