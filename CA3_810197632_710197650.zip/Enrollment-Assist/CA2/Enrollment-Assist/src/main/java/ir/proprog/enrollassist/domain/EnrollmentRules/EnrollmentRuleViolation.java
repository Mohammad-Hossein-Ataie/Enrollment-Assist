package ir.proprog.enrollassist.domain.EnrollmentRules;

import java.util.Objects;

public abstract class EnrollmentRuleViolation {
}


