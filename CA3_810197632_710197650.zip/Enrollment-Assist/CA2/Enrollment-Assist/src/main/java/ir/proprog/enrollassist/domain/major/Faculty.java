package ir.proprog.enrollassist.domain.major;

public enum Faculty {
    Engineering
}
